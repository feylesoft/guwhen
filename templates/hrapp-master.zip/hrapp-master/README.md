# hrapp
well im trying to build an e commerce app with kivy

Hr App
=======

### im really feelin lazy to build this

[ff me on facebook ](http://facebook.com/mcroni.com).
